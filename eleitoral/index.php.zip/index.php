<?php
$_SESSION['usuario']->cliente_vekttor_id='169';
$_SESSION['usuario']->usuario_tipo_id='200';
$vkt_id='169';
	//var_dump($_POST);
if($_POST['qtd_dependentes']>0){
	for($i=0;$i<=count($_POST['qtd_dependentes']);$i++){
		$_POST['dependente_nome'][$i]="filho ".($i+1);
		$_POST['dependente_vinculo'][$i]='6';
	}
}
include('../sis/_config.php');
include('../sis/_functions_base.php');
include('../sis/modulos/eleitoral/eleitores/_function.php');
include('../sis/modulos/eleitoral/eleitores/_ctrl.php');
if($_POST['action']=="Salvar"){
	echo "<script>alert('Cadastro Realizado Com Sucesso!');history.back();</script>";
}
?>