<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<title>Preenchimento de Formul&aacute;rio - Cinybuca&ccedil;&atilde;o de Dispensa - CD</title>
<link href="cd.css" rel="stylesheet" type="text/css" />
</head>

<body>
<table width="300" height="180" id='win_add_cont' border="0" cellspacing="0" cellpadding="0" style="margin:30px auto 0px auto; " >
  <form action="menu_arvore_actions.php" method="post" id="form1">
    <tr  >
      <td width="6" height="29"><img src="img/win_canto_e_s.gif" width="6" height="29" /></td>
      <td background="img/win_f_s.gif" class="titulo_janela" height="29">Acesso Restrito  <a href="#" onclick=""  class="arv_fecha_msg"></a></td>
      <td width="6" height="29"><img src="img/win_canto_d_s.gif" width="6" height="29" /></td>
    </tr>
    <tr>
      <td background="img/win_bor_e.gif" width="6">&nbsp;</td>
      <td height="150" align="center" valign="middle" bgcolor="#ECE9D8" >
	  Login : 
	    <input name="textfield" type="text" size="20" />
	    <br><br>
	  Senha : <input name="textfield" type="password" size="20" />
	  <br><br>
        <a href="#" onclick="arv_conteudo_add();document.getElementById('form1').submit()" class="arv_botao">
        
      Enviar</a></td>
      <td background="img/win_bor_d.gif" width="6">&nbsp;</td>
    </tr>
    <tr>
      <td width="6"><img src="img/win_canto_e_i.gif" width="6" height="3" /></td>
      <td background="img/win_f_i.gif" height="3"></td>
      <td width="6"><img src="img/win_canto_d_i.gif" width="6" height="3" /></td>
    </tr>
  </form>
</table>
</body>
</html>
