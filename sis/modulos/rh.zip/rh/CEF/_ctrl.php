<?php
	
	if($_GET['empresa_id']>0){
		
		gerar_cef($_GET);
	}