<?php
	function gerar_cef($dados){
		
		
	}