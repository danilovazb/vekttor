<?php

function consulta_por_competencia($campos){
	
	print_r($campos);
	
}

?>