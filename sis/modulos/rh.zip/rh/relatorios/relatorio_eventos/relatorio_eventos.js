// JavaScript Document
function listaEventosEmpresa(t){
	
	empresa_id=$(t).val();
	$(".evento_checkbox[data-rel=""]")
	
	
}