<?
//Includes
// configura��o inicial do sistema
include("../../../_config.php");
// fun��es base do sistema
include("../../../_functions_base.php");
// fun��es do modulo empreendimento
//include("modulos/rh/funcoes_rh.php");
include("../funcoes_rh.php");
include("_functions.php");
include("_ctrl.php"); 