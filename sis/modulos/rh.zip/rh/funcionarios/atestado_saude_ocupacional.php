<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=ISO-8859-1" />
<title>Atestado de Sa�de Ocupacional</title>
<style>
	.aso{
		border-collapse:collapse;
		width:800px;
		border-top:solid 1px #000000;
		border-left:solid 1px #000000;		
	}
	.aso tr td{
		border-bottom:solid 1px #000000;
		border-right:solid 1px #000000;
	}
	.check{
		width:6px;
		height:6px;
		border:solid 1px #000000;
	}
</style>
</head>

<body>
<table class="aso">
	<tr>
    	<td style="text-align:center;" colspan="3">ATESTADO DE SA�DE OCUPACIONAL (ASO)</td>
    </tr>
    <tr>
    	<td colspan="3">Nome:</td>
    </tr>
    <tr>
    	<td>Cargo/Fun��o:</td>
        <td>RG:</td>
        <td>Empresa:</td>
    </tr>
    <tr style="height:120px;">
    	<td colspan="3" style="padding:10px;" valign="top">
        	 
            Natureza do Exame:
        	<div class="check"></div>
        </td>
    </tr>
</table>
</body>
</html>