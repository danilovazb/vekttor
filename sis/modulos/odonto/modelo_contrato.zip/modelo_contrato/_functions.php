<?php
function manipulaContrato($dados,$vkt_id){
	
	$texto = $dados[texto];
	
	if($dados['id']>0){
		$inicio="UPDATE";
		$fim="WHERE id=".$dados['id'];
	}else{
		$inicio="INSERT INTO";
		$fim="";
	}
	$sql=mysql_query($t="$inicio odontologo_contrato_modelo SET 
			vkt_id='$vkt_id',
			nome='{$dados['nome']}',
			contrato='$texto'
			$fim");
			//echo $t;
			
}

function exclui_contrato($id){
	mysql_query($t="DELETE FROM odontologo_contrato_modelo WHERE id=$id");
	//echo $t." ".mysql_error();
}

?>